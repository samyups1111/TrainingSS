package samyups.example.trainingss

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class DogAdapter: RecyclerView.Adapter<DogViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DogViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.dogRV)

    }

    override fun onBindViewHolder(holder: DogViewHolder, position: Int) {
        TODO("Not yet implemented")
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")
    }
}

class DogViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {

}